<?php
$website_modal_data_query = 'SELECT * FROM  trinity_modals WHERE trinity_modal_id=1';
foreach ($connread->query($website_modal_data_query) as $row) {
$trinity_modal_title=$row['trinity_modal_title'];		
$trinity_modal_text=$row['trinity_modal_text'];		
}
?>