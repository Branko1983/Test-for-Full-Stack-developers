<?php
 if (isset($_POST['admin-login'])) { 
    $trinity_admin_user = !empty($_POST['trinity_admin_user']) ? trim($_POST['trinity_admin_user']) : null;
    $trinity_admin_pwd = !empty($_POST['trinity_admin_pwd']) ? trim($_POST['trinity_admin_pwd']) : null;
    $trinity_admin_user1 = htmlspecialchars($trinity_admin_user, ENT_QUOTES);
    $trinity_admin_pwd1 = htmlspecialchars($trinity_admin_pwd, ENT_QUOTES);	 
	 
	$enc_trinity_admin_pwd1=md5($trinity_admin_pwd1);
    $tr_login_query = "SELECT * FROM trinity_admin WHERE trinity_admin_user=:trinity_admin_user AND trinity_admin_pwd=:trinity_admin_pwd";
    $stmt = $connwrite->prepare($tr_login_query);
	   //Bind value.
    $stmt->bindParam(':trinity_admin_user', $trinity_admin_user1, PDO::PARAM_STR);
    $stmt->bindParam(':trinity_admin_pwd', $enc_trinity_admin_pwd1, PDO::PARAM_STR);
  // bind the parameters and execute the statement	
  // execute and get number of affected rows
    $stmt->execute();
    $OK = $stmt->rowCount();
	if ($OK!=0){
   $tr_logintwo_query = "SELECT * FROM trinity_admin WHERE trinity_admin_user='$trinity_admin_user1' AND trinity_admin_pwd='$enc_trinity_admin_pwd1'";
    $stmt = $connwrite->prepare($tr_logintwo_query);		
    foreach ($connread->query($tr_logintwo_query) as $row) {
         $_SESSION["trinity_admin_id"] = $row['trinity_admin_id'];
        }   
	}
  }
if (!isset($_SESSION["trinity_admin_id"])) {
header('Location:login.php');
}
?>