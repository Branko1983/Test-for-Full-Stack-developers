<?php
session_start();
include '../includes/connection.inc.php';
$connread = dbConnect('read', 'pdo');
$connwrite = dbConnect('write', 'pdo');
$link_prefix='http://topwebsolutions2019.com/trinityrank/admin/';
?>
<?php
include 'PHP/login-code.php';
?>
<?php
include 'PHP/modal-data.php';
?>
<!DOCTYPE html>
<html lang="en" class="no-js">
<head>
    <meta charset="UTF-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin panel for controlling website</title>
    <meta name="description" content="Loading Effects for Grid Items with CSS Animations"/>
    <meta name="keywords" content="css animation, loading effect, google plus, grid items, masonry"/>
    <meta name="author" content="Codrops"/>
	<link rel="stylesheet" type="text/css" href="css/admin.css?<?php echo date('l jS \of F Y h:i:s A'); ?>" />
    <link rel="stylesheet" type="text/css" href="css/admin-login.css?<?php echo date('l jS \of F Y h:i:s A'); ?>" />
    <link rel="stylesheet" type="text/css" href="css/trinity.css?<?php echo date('l jS \of F Y h:i:s A'); ?>" />	
    <link rel="stylesheet" type="text/css" href="css/default.css"/>
    <link rel="stylesheet" type="text/css" href="css/component.css"/>
    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css"/>
	<style>
	#tr-admin-left ul{
margin-left:-30px;
}
#tr-admin-left span{
padding-top:4px;
margin-right:12px;
margin-left:20px;
}
#tr-admin-left ul li{
list-style-type:none;
position: relative;
margin-left:-9px;
border-left:3px solid #222c3c;
}
#tr-admin-left ul li:hover{
border-left:3px solid #8dbbf9;
background:#1c2534;
color:#fff;
}
#tr-admin-left ul li.current{
border-left:3px solid #8dbbf9;
background:#1c2534;
color:#fff;
}
#tr-admin-left ul li.current a{
color:#fff;
}
#tr-admin-left ul li a{
color:#b7c0cd;
display: block; height: 100%; width:100%;
padding-top:10px;
padding-bottom:10px;
font-size:13px!important;
}

#tr-admin-left ul li a:hover{
color:#fff;
cursor:pointer;
text-decoration:none;
display:block;
height:100%;
}
	</style>
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
    <script src="bootstrap/js/bootstrap.js"></script>
</head>
<body>
<div id="tr-admin-header">
<p>Hi, Admin</p>
</div>
<div id="tr-admin-left">
<br><br>
<ul>
<li class=""><a href="../index.php" target="_blank"><i class="fa fa-bookmark" style="margin-left:20px!important; margin-right:10px!important;" aria-hidden="true"></i> Website</a></li>
<li class=""><a href="index.php"><i class="fa fa-sliders" style="margin-left:20px!important; margin-right:10px!important;" aria-hidden="true"></i> Settings</a></li>	
<li class=""><a href="logout.php"><i class="fa fa-sign-out" style="margin-left:20px!important; margin-right:10px!important;" aria-hidden="true"></i> Logout</a></li>
</ul>
</div>
<div id="tr-main-page">
<div class="padding20">
<h3>Settings page</h3>

<h4>Modal title</h4>
<input type="text" class="form-control" value="<?php echo $trinity_modal_title;?>" id="trinity_modal_title" required  data-toggle="tooltip" data-placement="right" title="">
<h4>Website modal text</h4>
<textarea id="trinity_modal_text" class="ckeditor" cols="80"  rows="10" style="width: 480px;  padding-top:20px!important; padding-left:15px!important; height:180px;
                border-color: #66afe9; 
                -webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075), 0 0 8px rgba(102, 175, 233, .6);
                box-shadow: inset 0 1px 1px rgba(0,0,0,.075), 0 0 8px rgba(102, 175, 233, .6); margin-bottom:0px!important;" ><?php echo $trinity_modal_text;?></textarea>
<h4>Choose posts where modal should be displayed</h4>
<?php
$website_modal_types_query = 'SELECT * FROM  trinity_modal_post_types';
foreach ($connread->query($website_modal_types_query) as $row) {
$trinity_modal_post_type_id=$row['trinity_modal_post_type_id'];		
$trinity_modal_post_type=$row['trinity_modal_post_type'];		
$trinity_modal_post_type_displayed=$row['trinity_modal_post_type_displayed'];
if($trinity_modal_post_type_displayed==1){
$checked_type='checked';	
}	
else{
$checked_type='';	
}	
?>
<div class="checkbox">
  <label style="font-size:14px!important;"><input  type="checkbox" id="select-modal-type<?php echo $trinity_modal_post_type_id;?>" value=""><?php echo $trinity_modal_post_type;?></label>
</div>
<?php } ?>

<div id="all-pages-html">
<?php include 'HTML/all-pages.html';?>
</div>
<a href="#fddffdfd" id="update_changes" class="btn btn-primary">Save changes</a>
</div>
</div>

<?php
$website_modal_types_query = 'SELECT * FROM  trinity_modal_post_types';
foreach ($connread->query($website_modal_types_query) as $row) {
$trinity_modal_post_type_id=$row['trinity_modal_post_type_id'];			
?>
<script type="text/javascript">
$('#select-modal-type<?php echo $trinity_modal_post_type_id;?>').click(function(){
	var trinity_modal_post_type_id = <?php echo $trinity_modal_post_type_id;?>;	
    if($(this).is(':checked')){	  
                  $.ajax({
		          type: "POST",
                  url: "<?php echo $link_prefix;?>select-modal-type-ajax.php",
                  data:"trinity_modal_post_type_id="+trinity_modal_post_type_id, 
                  cache:false,datatype: 'html',async:false,	 
                  success: function(data){	
		          $('#all-pages-html').html(data);
				  }
                  });
    } else {	  
                  $.ajax({
		          type: "POST",
                  url: "<?php echo $link_prefix;?>deselect-modal-type-ajax.php",
                  data:"trinity_modal_post_type_id="+trinity_modal_post_type_id, 
                  cache:false,datatype: 'html',async:false,	 
                  success: function(data){	
		          $('#all-pages-html').html(data);		
				  }
                  });
    }
});
</script>
<?php } ?>

<script type="text/javascript">
$('#update_changes').click(function(){
	var trinity_modal_title = $("#trinity_modal_title").val();
	var trinity_modal_text = $("#trinity_modal_text").val();	
                  $.ajax({
		          type: "POST",
                  url: "<?php echo $link_prefix;?>update-modal-ajax.php",
                  data:"trinity_modal_title="+trinity_modal_title+"&trinity_modal_text="+trinity_modal_text, 
                  cache:false,datatype: 'html',async:false,	 
                  success: function(data){	
		          alert('You have succesfully save your changes');
				  }
                  });
<?php
$website_modal_pages_query = "SELECT * FROM  trinity_pages";
foreach ($connread->query($website_modal_pages_query) as $row) {
$trinity_page_id=$row['trinity_page_id'];
?>
var trinity_page_id = <?php echo $trinity_page_id;?>;	
   if($("#select-modal-page<?php echo $trinity_page_id;?>").is(':selected')){     
$.ajax({
		          type: "POST",
                  url: "<?php echo $link_prefix;?>update-modal-to-page-ajax.php",
                  data:"trinity_page_id="+trinity_page_id, 
                  cache:false,datatype: 'html',async:false,	 
                  success: function(data){	

				  }
                  });
        }
		else{
$.ajax({
		          type: "POST",
                  url: "<?php echo $link_prefix;?>deselect-modal-to-page-ajax.php",
                  data:"trinity_page_id="+trinity_page_id, 
                  cache:false,datatype: 'html',async:false,	 
                  success: function(data){	

				  }
                  });			
		}
<?php } ?>			  
});
</script>

</body>
</html>