<?php
ob_start();
$aip = $_SERVER['REMOTE_ADDR'];
$bip = $_SERVER['HTTP_X_FORWARDED_FOR'];
$agent = $_SERVER['HTTP_USER_AGENT'];
session_start();
// Do this each time the user successfully logs in.
$_SESSION['ident'] = hash("sha256", $aip . $bip . $agent);

// Do this every time the client makes a request to the server, after authenticating
$ident = hash("sha256", $aip . $bip . $agent);
if ($ident != $_SESSION['ident'])
{
    end_session();
    header("Location: index.php");
    // add some fancy pants GET/POST var headers for login.php, that lets you
    // know in the login page to notify the user of why they're being challenged
    // for login again, etc.
}
$ip = $_SERVER['REMOTE_ADDR'];
if (isset($_GET["visitors-page"])) {
$visitors_page=htmlspecialchars($_GET["visitors-page"], ENT_QUOTES);
}
include '../includes/connection.inc.php';
$connread = dbConnect('read', 'pdo');
$connwrite = dbConnect('write', 'pdo');
$trinity_page_id=$_POST['trinity_page_id'];
      $OK = false;
        $update_website_options_query = "UPDATE trinity_pages SET 	trinity_page_modal_displayed=0 WHERE trinity_page_id=$trinity_page_id";
        $stmt = $connwrite->prepare($update_website_options_query);
        // bind the parameters and execute the statement	
        // execute and get number of affected rows	
        $stmt->execute();
        $OK = $stmt->rowCount();
?>

 