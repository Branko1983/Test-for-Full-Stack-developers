<?php
ob_start();
$aip = $_SERVER['REMOTE_ADDR'];
$bip = $_SERVER['HTTP_X_FORWARDED_FOR'];
$agent = $_SERVER['HTTP_USER_AGENT'];
session_start();
include_once 'google/gpConfig.php';
// Do this each time the user successfully logs in.
$_SESSION['ident'] = hash("sha256", $aip . $bip . $agent);

// Do this every time the client makes a request to the server, after authenticating
$ident = hash("sha256", $aip . $bip . $agent);
if ($ident != $_SESSION['ident'])
{
    end_session();
    header("Location: index.php");
    // add some fancy pants GET/POST var headers for login.php, that lets you
    // know in the login page to notify the user of why they're being challenged
    // for login again, etc.
}
$ip = $_SERVER['REMOTE_ADDR'];
if (isset($_GET["visitors-page"])) {
$visitors_page=htmlspecialchars($_GET["visitors-page"], ENT_QUOTES);
}
include 'includes/connection.inc.php';
$connread = dbConnect('read', 'pdo');
$connwrite = dbConnect('write', 'pdo');
?>
<html>
<head>
 <link rel="stylesheet" type="text/css" href="admin/css/admin.css?<?php echo date('l jS \of F Y h:i:s A'); ?>" />
 <link rel="stylesheet" type="text/css" href="admin/css/default.css"/>
 <link rel="stylesheet" type="text/css" href="admin/css/component.css"/>
<style>
.wrapper{
width:1024px!important;		
margin:0 auto;
}
#navigation{
height:50px!important;
width:100%;
color:#fff;		
background:#45bbff;
}
#navigation a{
color:#fff;
font-size:17px;
text-decoration:none!important;
margin-right:20px!important;
}
#navigation a:hover{
color:#eee;
}
</style>  
<link rel="stylesheet" type="text/css" href="admin/bootstrap/css/bootstrap.css" /> 
</head>
<body>
<!-- Side page of the Admin panel ------ START -->
<?php include 'HTML/navigation.html';?>
<!-- Side page of the Admin panel ------ END -->
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<?php
$website_nav_query = "SELECT * FROM trinity_modal_post_types";
foreach ($connread->query($website_nav_query) as $row) {
$trinity_modal_post_type_id=$row['trinity_modal_post_type_id'];	
?>
<script>
$("#nav-modal<?php echo $trinity_modal_post_type_id;?>").click(function(){
  $("#nav-modal-submenu<?php echo $trinity_modal_post_type_id;?>").slideToggle();  
})
</script>
<?php } ?>
</body>
</html>