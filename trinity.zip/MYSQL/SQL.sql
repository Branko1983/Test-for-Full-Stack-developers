-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Oct 07, 2019 at 07:53 AM
-- Server version: 5.6.43
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `branko83_trinity`
--

-- --------------------------------------------------------

--
-- Table structure for table `trinity_admin`
--

CREATE TABLE `trinity_admin` (
  `trinity_admin_id` int(11) NOT NULL,
  `trinity_admin_user` varchar(100) NOT NULL,
  `trinity_admin_pwd` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `trinity_admin`
--

INSERT INTO `trinity_admin` (`trinity_admin_id`, `trinity_admin_user`, `trinity_admin_pwd`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3');

-- --------------------------------------------------------

--
-- Table structure for table `trinity_modals`
--

CREATE TABLE `trinity_modals` (
  `trinity_modal_id` int(11) NOT NULL,
  `trinity_modal_title` varchar(30) NOT NULL,
  `trinity_modal_text` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `trinity_modals`
--

INSERT INTO `trinity_modals` (`trinity_modal_id`, `trinity_modal_title`, `trinity_modal_text`) VALUES
(1, 'This is modal title', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.');

-- --------------------------------------------------------

--
-- Table structure for table `trinity_modal_post_types`
--

CREATE TABLE `trinity_modal_post_types` (
  `trinity_modal_post_type_id` int(11) NOT NULL,
  `trinity_modal_post_type` varchar(20) NOT NULL,
  `trinity_modal_post_type_displayed` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `trinity_modal_post_types`
--

INSERT INTO `trinity_modal_post_types` (`trinity_modal_post_type_id`, `trinity_modal_post_type`, `trinity_modal_post_type_displayed`) VALUES
(1, 'Posts', 1),
(2, 'Pages', 1),
(3, 'Companies (CPT)', 1),
(4, 'Reviews (CPT)', 1),
(5, 'Team (CPT)', 1);

-- --------------------------------------------------------

--
-- Table structure for table `trinity_pages`
--

CREATE TABLE `trinity_pages` (
  `trinity_page_id` int(11) NOT NULL,
  `trinity_page_content` text NOT NULL,
  `trinity_modal_post_type_id` int(11) NOT NULL,
  `trinity_page_timestamp` int(11) NOT NULL,
  `trinity_page_modal_displayed` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `trinity_pages`
--

INSERT INTO `trinity_pages` (`trinity_page_id`, `trinity_page_content`, `trinity_modal_post_type_id`, `trinity_page_timestamp`, `trinity_page_modal_displayed`) VALUES
(1, 'Page1', 1, 1570350249, 0),
(2, 'Page2', 1, 1570350449, 0),
(3, 'Page3', 3, 1570350469, 1),
(4, 'Page4', 2, 1570351449, 0),
(5, 'Page5', 5, 1570350449, 0),
(6, 'Page6', 2, 1570350449, 0),
(7, 'Page7', 4, 1570350449, 0),
(8, 'Page8', 1, 1570350449, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `trinity_admin`
--
ALTER TABLE `trinity_admin`
  ADD PRIMARY KEY (`trinity_admin_id`);

--
-- Indexes for table `trinity_modals`
--
ALTER TABLE `trinity_modals`
  ADD PRIMARY KEY (`trinity_modal_id`);

--
-- Indexes for table `trinity_modal_post_types`
--
ALTER TABLE `trinity_modal_post_types`
  ADD PRIMARY KEY (`trinity_modal_post_type_id`);

--
-- Indexes for table `trinity_pages`
--
ALTER TABLE `trinity_pages`
  ADD PRIMARY KEY (`trinity_page_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `trinity_admin`
--
ALTER TABLE `trinity_admin`
  MODIFY `trinity_admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `trinity_modals`
--
ALTER TABLE `trinity_modals`
  MODIFY `trinity_modal_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `trinity_modal_post_types`
--
ALTER TABLE `trinity_modal_post_types`
  MODIFY `trinity_modal_post_type_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `trinity_pages`
--
ALTER TABLE `trinity_pages`
  MODIFY `trinity_page_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
